import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.cluster import KMeans
from sklearn.cluster import DBSCAN

from sklearn.metrics import silhouette_score
from sklearn.preprocessing import StandardScaler

# -----------------------------
# Load Dataset
# -----------------------------
df = pd.read_csv("dataset.csv")

# -----------------------------
# Display Dataset
# -----------------------------
print(df.head())

# -----------------------------
# Heatmap Graph
# -----------------------------
plt.figure(figsize=(8,6))

sns.heatmap(
    df.corr(numeric_only=True),
    annot=True,
    cmap='coolwarm'
)

plt.title("Feature Correlation Heatmap")

plt.show()

# -----------------------------
# Select Features
# -----------------------------
X = df.iloc[:, [3, 4]]

# -----------------------------
# Feature Scaling
# -----------------------------
scaler = StandardScaler()

X_scaled = scaler.fit_transform(X)

# -----------------------------
# Elbow Method
# -----------------------------
wcss = []

for i in range(1, 11):

    kmeans = KMeans(
        n_clusters=i,
        init='k-means++',
        random_state=42
    )

    kmeans.fit(X_scaled)

    wcss.append(kmeans.inertia_)

# -----------------------------
# Elbow Graph
# -----------------------------
plt.figure(figsize=(8,5))

plt.plot(range(1,11), wcss, marker='o')

plt.title("Elbow Method")
plt.xlabel("Number of Clusters")
plt.ylabel("WCSS")

plt.show()

# -----------------------------
# Apply KMeans
# -----------------------------
kmeans = KMeans(
    n_clusters=5,
    init='k-means++',
    random_state=42
)

y_kmeans = kmeans.fit_predict(X_scaled)

# -----------------------------
# Customer Segmentation Graph
# -----------------------------
plt.figure(figsize=(10,7))

# Premium Customers
plt.scatter(
    X_scaled[y_kmeans == 0, 0],
    X_scaled[y_kmeans == 0, 1],
    s=100,
    label='Premium Customers'
)

# Regular Customers
plt.scatter(
    X_scaled[y_kmeans == 1, 0],
    X_scaled[y_kmeans == 1, 1],
    s=100,
    label='Regular Customers'
)

# Budget Customers
plt.scatter(
    X_scaled[y_kmeans == 2, 0],
    X_scaled[y_kmeans == 2, 1],
    s=100,
    label='Budget Customers'
)

# Careful Customers
plt.scatter(
    X_scaled[y_kmeans == 3, 0],
    X_scaled[y_kmeans == 3, 1],
    s=100,
    label='Careful Customers'
)

# Target Customers
plt.scatter(
    X_scaled[y_kmeans == 4, 0],
    X_scaled[y_kmeans == 4, 1],
    s=100,
    label='Target Customers'
)

# Centroids
plt.scatter(
    kmeans.cluster_centers_[:,0],
    kmeans.cluster_centers_[:,1],
    s=300,
    c='black',
    marker='X',
    label='Centroids'
)

# -----------------------------
# Graph Labels
# -----------------------------
plt.title("Customer Segmentation using K-Means")
plt.xlabel("Annual Income")
plt.ylabel("Spending Score")

plt.legend()

plt.show()

# -----------------------------
# Add Cluster Column
# -----------------------------
df['Cluster'] = y_kmeans

# -----------------------------
# Add Customer Labels
# -----------------------------
cluster_names = {
    0: 'Premium Customers',
    1: 'Regular Customers',
    2: 'Budget Customers',
    3: 'Careful Customers',
    4: 'Target Customers'
}

df['Customer_Type'] = df['Cluster'].map(cluster_names)

# -----------------------------
# Display Updated Dataset
# -----------------------------
print(df.head())

# -----------------------------
# Save Updated Dataset
# -----------------------------
df.to_csv("clustered_customers.csv", index=False)

print("Clustered dataset saved successfully!")

# -----------------------------
# K-Means Silhouette Score
# -----------------------------
kmeans_score = silhouette_score(X_scaled, y_kmeans)

print("\nK-Means Silhouette Score:", kmeans_score)

# -----------------------------
# DBSCAN Clustering
# -----------------------------
dbscan = DBSCAN(
    eps=0.5,
    min_samples=5
)

dbscan_labels = dbscan.fit_predict(X_scaled)

# -----------------------------
# DBSCAN Graph
# -----------------------------
plt.figure(figsize=(10,7))

plt.scatter(
    X_scaled[:,0],
    X_scaled[:,1],
    c=dbscan_labels,
    s=100
)

plt.title("DBSCAN Customer Segmentation")
plt.xlabel("Annual Income")
plt.ylabel("Spending Score")

plt.show()

# -----------------------------
# DBSCAN Silhouette Score
# -----------------------------
if len(set(dbscan_labels)) > 1:

    dbscan_score = silhouette_score(X_scaled, dbscan_labels)

    print("\nDBSCAN Silhouette Score:", dbscan_score)

else:
    print("\nDBSCAN was unable to form multiple clusters.")